var builder = WebApplication.CreateBuilder(args);

// Registra los servicios necesarios: soporte para controladores
// y Swagger (documentación interactiva de la API).
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Permite que el juego (que corre en otro proceso/puerto) pueda llamar a esta API.
builder.Services.AddCors(options =>
{
    options.AddPolicy("PermitirJuego", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(); // Disponible en /swagger para probar el endpoint desde el navegador
}

app.UseCors("PermitirJuego");
app.UseAuthorization();
app.MapControllers();

app.Run();
