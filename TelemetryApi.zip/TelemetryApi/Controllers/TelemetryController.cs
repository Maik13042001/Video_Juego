using Microsoft.AspNetCore.Mvc;
using TelemetryApi.Models;

namespace TelemetryApi.Controllers
{
    [ApiController]
    [Route("api/telemetry")]
    public class TelemetryController : ControllerBase
    {
        // Lista en memoria solo para este ejemplo.
        // En un juego real, aquí guardarías en una base de datos
        // (SQL Server, PostgreSQL, MongoDB, etc.) o enviarías a un servicio de analítica.
        private static readonly List<TelemetryEvent> _events = new();

        // POST api/telemetry/events
        // Este es el endpoint que tu juego en C# va a llamar.
        [HttpPost("events")]
        public ActionResult<TelemetryResponse> ReceiveEvent([FromBody] TelemetryEvent telemetryEvent)
        {
            // ASP.NET Core ya intentó "parsear" el JSON a un objeto TelemetryEvent.
            // Si el JSON viene mal formado (ej. le falta una llave), esto nunca
            // llega a ejecutarse: el framework responde 400 automáticamente.

            // Aquí revisamos las reglas de validación definidas en el modelo
            // (los [Required], [StringLength], etc.)
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Validación extra de negocio que las anotaciones no cubren:
            if (telemetryEvent.Timestamp > DateTime.UtcNow.AddMinutes(5))
            {
                return BadRequest(new { error = "Timestamp no puede estar en el futuro" });
            }

            _events.Add(telemetryEvent);

            Console.WriteLine(
                $"[Telemetría] {telemetryEvent.EventType} | jugador={telemetryEvent.PlayerId} | hora={telemetryEvent.Timestamp}");

            var response = new TelemetryResponse
            {
                Status = "recibido",
                EventId = _events.Count
            };

            return Ok(response);
        }

        // GET api/telemetry/events
        // Endpoint auxiliar para que puedas revisar qué se ha recibido (útil para pruebas)
        [HttpGet("events")]
        public ActionResult<IEnumerable<TelemetryEvent>> GetAllEvents()
        {
            return Ok(_events);
        }
    }
}
