// -----------------------------------------------------------------------
// ESTE ARCHIVO ES SOLO UN EJEMPLO de cómo se vería el código DEL JUEGO
// (no del servidor) enviando un evento de telemetría.
// No forma parte del proyecto TelemetryApi; podrías copiarlo a tu proyecto
// de juego (Unity, consola, etc.) y adaptarlo.
// -----------------------------------------------------------------------

using System.Net.Http.Json;

public class ClienteTelemetria
{
    private static readonly HttpClient _http = new HttpClient
    {
        BaseAddress = new Uri("https://localhost:5001/") // URL de tu servidor
    };

    public async Task EnviarEventoAsync(string eventType, string playerId, object payload)
    {
        var evento = new
        {
            EventType = eventType,
            PlayerId = playerId,
            Timestamp = DateTime.UtcNow,
            Payload = payload
        };

        // PostAsJsonAsync convierte automáticamente el objeto a JSON
        // y hace la petición POST al endpoint.
        var respuesta = await _http.PostAsJsonAsync("api/telemetry/events", evento);

        if (respuesta.IsSuccessStatusCode)
        {
            Console.WriteLine("Evento enviado correctamente");
        }
        else
        {
            var error = await respuesta.Content.ReadAsStringAsync();
            Console.WriteLine($"Error al enviar evento: {error}");
        }
    }
}

// Ejemplo de uso dentro del juego, cuando el jugador muere:
//
// var cliente = new ClienteTelemetria();
// await cliente.EnviarEventoAsync(
//     eventType: "player_death",
//     playerId: "jugador123",
//     payload: new { nivel = 3, causa = "caida" }
// );
