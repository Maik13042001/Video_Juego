using System.ComponentModel.DataAnnotations;

namespace TelemetryApi.Models
{
    // Este es el "contrato" del JSON que el juego debe enviar.
    // Cada atributo como [Required] es una regla de validación:
    // si el juego no la cumple, ASP.NET Core rechaza la petición automáticamente.
    public class TelemetryEvent
    {
        [Required(ErrorMessage = "EventType es obligatorio")]
        [StringLength(50, ErrorMessage = "EventType no puede superar 50 caracteres")]
        public string EventType { get; set; } = string.Empty;

        [Required(ErrorMessage = "PlayerId es obligatorio")]
        public string PlayerId { get; set; } = string.Empty;

        [Required(ErrorMessage = "Timestamp es obligatorio")]
        public DateTime Timestamp { get; set; }

        // Payload es libre: aquí va la info específica de cada tipo de evento
        // (por ejemplo, nivel alcanzado, causa de muerte, ítem comprado, etc.)
        public Dictionary<string, object>? Payload { get; set; }
    }

    // Esta clase define cómo se ve la respuesta que el servidor
    // le devuelve al juego después de recibir un evento.
    public class TelemetryResponse
    {
        public string Status { get; set; } = "recibido";
        public int EventId { get; set; }
        public DateTime ReceivedAt { get; set; } = DateTime.UtcNow;
    }
}
