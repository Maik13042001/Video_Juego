// -----------------------------------------------------------------------
// SCRIPT DE PRUEBA: envía un evento de telemetría apenas arranca la escena.
// Colócalo en el mismo GameObject "TelemetryManager" que tiene TelemetryClient.
// Sirve solo para verificar que la conexión funciona; luego lo puedes borrar
// o reemplazar por las llamadas reales desde tu lógica de juego
// (muerte del jugador, nivel completado, etc.)
// -----------------------------------------------------------------------

using System.Collections.Generic;
using UnityEngine;

public class TestSender : MonoBehaviour
{
    void Start()
    {
        var cliente = GetComponent<TelemetryClient>();

        if (cliente == null)
        {
            Debug.LogError("No se encontró el componente TelemetryClient en este GameObject");
            return;
        }

        var payload = new Dictionary<string, object>
        {
            { "nivel", 3 },
            { "causa", "caida" }
        };

        cliente.EnviarEvento("player_death", "jugador123", payload);

        Debug.Log("Evento de prueba enviado, revisa la consola en unos segundos...");
    }
}
