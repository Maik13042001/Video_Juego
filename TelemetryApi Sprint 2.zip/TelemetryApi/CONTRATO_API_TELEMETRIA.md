# Contrato REST — Endpoint de Telemetría

**Ticket relacionado:** SCRUM-40 (documentación) / US-04 (implementación)

## Descripción

Endpoint que recibe eventos de telemetría del videojuego (acciones del jugador como muertes, niveles completados, compras, etc.), valida su estructura y los registra para su posterior análisis.

---

## POST /api/v1/telemetry/events

Registra un nuevo evento de telemetría.

### Request

**Método:** `POST`
**URL:** `/api/v1/telemetry/events`
**Content-Type:** `application/json`

**Cuerpo (body):**

| Campo       | Tipo                 | Obligatorio | Descripción                                                  |
|-------------|----------------------|-------------|----------------------------------------------------------------|
| `eventType` | string (máx. 50)     | Sí          | Tipo de evento (ej. `player_death`, `level_complete`, `purchase`) |
| `playerId`  | string               | Sí          | Identificador único del jugador                                |
| `timestamp` | string (ISO 8601)    | Sí          | Momento en que ocurrió el evento. No puede ser futuro (tolerancia de 5 min) |
| `payload`   | objeto (libre)        | No          | Datos adicionales específicos del tipo de evento                |

**Ejemplo de request:**

```json
{
  "eventType": "player_death",
  "playerId": "jugador123",
  "timestamp": "2026-10-04T15:30:00Z",
  "payload": {
    "nivel": 3,
    "causa": "caida"
  }
}
```

### Responses

**200 OK** — El evento fue recibido y registrado correctamente.

```json
{
  "status": "recibido",
  "eventId": 1,
  "receivedAt": "2026-10-04T15:30:01Z"
}
```

**400 Bad Request** — El JSON no cumple el contrato (falta un campo obligatorio, tipo incorrecto, o el `timestamp` está en el futuro).

```json
{
  "errors": {
    "EventType": ["EventType es obligatorio"]
  }
}
```

---

## GET /api/v1/telemetry/events

Devuelve la lista de todos los eventos recibidos. Pensado para pruebas y depuración, no para uso en producción por el juego.

### Request

**Método:** `GET`
**URL:** `/api/v1/telemetry/events`

### Response

**200 OK**

```json
[
  {
    "eventType": "player_death",
    "playerId": "jugador123",
    "timestamp": "2026-10-04T15:30:00Z",
    "payload": { "nivel": 3, "causa": "caida" }
  }
]
```

---

## Reglas de validación

- `eventType` y `playerId` no pueden estar vacíos.
- `eventType` no puede superar 50 caracteres.
- `timestamp` es obligatorio y no puede ser una fecha más de 5 minutos en el futuro (para evitar datos corruptos del reloj del cliente).
- `payload` es opcional y de estructura libre; no se valida su contenido interno en esta versión.

## Notas de implementación

- Los eventos se almacenan actualmente en memoria (se pierden al reiniciar el servidor). Pendiente: persistencia en base de datos.
- CORS está habilitado para permitir llamadas desde el proceso del juego (Unity).
- Documentación interactiva disponible en `/swagger` cuando el servidor corre en modo desarrollo.
